package org.lab11.model;

public class User {
    private String userName;
    private String password;

    public User(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || this.getClass() != o.getClass()) return false;
        User user = (User) o;
        boolean isEqual = user.userName.equals(this.userName) && user.password.equals(this.password);
        return isEqual;
    }
}
