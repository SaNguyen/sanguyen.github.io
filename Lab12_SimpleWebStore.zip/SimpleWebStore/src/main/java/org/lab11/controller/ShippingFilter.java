package org.lab11.controller;

public class ShippingFilter {
}
